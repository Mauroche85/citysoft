package ocss.nmea.api;

import java.util.EventListener;
import ocss.nmea.api.NMEAEvent;

public class NMEAListener implements EventListener 
{
  public void dataDetected(NMEAEvent e)
  {
  }
  public void dataRead(NMEAEvent e)
  {
  }
  public void stopReading(NMEAEvent e)
  {
  }
}